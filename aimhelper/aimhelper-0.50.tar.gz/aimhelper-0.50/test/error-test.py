from PyQt6.QtWidgets import QApplication, QMessageBox

app = QApplication([])

QMessageBox.critical(None, "Aim Error", "Some Error")
